window.globalConfig = {
    ROUTE: 'http://127.0.0.1:8000/',
    VERSIONS: 'v1/',
    MEROUTE: 'http://127.0.0.1:5000/'
};